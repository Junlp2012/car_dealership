@echo off
cd /d C:\Users\34558\car_dealership_app
python app.py
pause