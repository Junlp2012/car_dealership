CREATE TABLE IF NOT EXISTS usertble (
    id SERIAL PRIMARY KEY,
    name VARCHAR(80) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);
CREATE TABLE IF NOT EXISTS logtble (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES usertble(id),
    login_datetime TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    logout_datetime TIMESTAMPTZ NULL,
    session_token VARCHAR(64) UNIQUE NOT NULL
);
CREATE TABLE IF NOT EXISTS cartble (
    id SERIAL PRIMARY KEY,
    make VARCHAR(60) NOT NULL,
    model VARCHAR(80) NOT NULL,
    year INTEGER NOT NULL,
    category VARCHAR(10) NOT NULL CHECK (category IN ('New', 'Used')),
    price NUMERIC(12,2) NOT NULL CHECK (price >= 0),
    description TEXT,
    status VARCHAR(15) NOT NULL DEFAULT 'Available' CHECK (status IN ('Available', 'Sold')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS cartxntble (
    id SERIAL PRIMARY KEY,
    car_id INTEGER NOT NULL REFERENCES cartble(id),
    employee_id INTEGER NOT NULL REFERENCES usertble(id),
    transaction_type VARCHAR(10) NOT NULL CHECK (transaction_type IN ('Sale', 'Purchase')),
    amount NUMERIC(12,2) NOT NULL CHECK (amount >= 0),
    customer_name VARCHAR(120),
    notes TEXT,
    transaction_datetime TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS customer_selectiontble (
    id SERIAL PRIMARY KEY,
    customer_name VARCHAR(120) NOT NULL,
    email VARCHAR(160),
    phone VARCHAR(40),
    car_ids TEXT NOT NULL,
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_usertble_name ON usertble(name);
CREATE INDEX IF NOT EXISTS ix_logtble_user_id ON logtble(user_id);
CREATE INDEX IF NOT EXISTS ix_cartble_status ON cartble(status);
CREATE INDEX IF NOT EXISTS ix_cartxntble_car_id ON cartxntble(car_id);
