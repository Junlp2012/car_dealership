# AutoLot Dealership Web Application

Python / Flask + HTML + CSS + JavaScript + PostgreSQL.

## Features

### Public customer page
- Open `/` without logging in.
- Browse available New and Used cars and their USD prices.
- Select multiple cars and submit name, email, and phone.
- Customer selections are saved for employees to review.

### Employee-only pages
- Open `/employee/login`.
- Existing employee accounts in `usertble` can sign in.
- Employee dashboard can add inventory, record a sale, and record a used-car purchase.
- Selling a car marks it Sold and creates a Sale transaction.
- Buying a used car creates a Used/Available inventory record and a Purchase transaction.
- Dashboard shows inventory, recent customer selections, and recent transactions.

## Database tables

- `usertble`: employee accounts; `password` stores a Werkzeug password hash.
- `logtble`: employee login/logout timestamps.
- `cartble`: vehicle details, New/Used category, USD price, and Available/Sold status.
- `cartxntble`: employee-recorded Sale and Purchase transactions.
- `customer_selectiontble`: customer contact details and selected car IDs.

## Setup on Windows PowerShell

1. Install PostgreSQL and create a database:

   ```sql
   CREATE DATABASE car_dealership;
   CREATE USER login_app WITH PASSWORD 'choose-a-strong-password';
   GRANT ALL PRIVILEGES ON DATABASE car_dealership TO login_app;
   ```

   Connect to `car_dealership` and run:

   ```sql
   GRANT ALL ON SCHEMA public TO login_app;
   ```

2. Open PowerShell in this project folder:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   ```

3. Set database connection and secret:

   ```powershell
   $env:SECRET_KEY="replace-with-a-long-random-secret"
   $env:DATABASE_URL="postgresql+psycopg://login_app:choose-a-strong-password@localhost:5432/car_dealership"
   ```

   If your PostgreSQL username/password/database differ, update the URL. If the password contains special URL characters, URL-encode them.

4. Create the tables:

   ```powershell
   flask --app app init-db
   ```

5. Create an employee account:

   ```powershell
   flask --app app create-user
   ```

   Enter an employee username and password when prompted.

6. Start the app:

   ```powershell
   python app.py
   ```

7. Open:
   - Customer page (no login): `http://127.0.0.1:5000/`
   - Employee login: `http://127.0.0.1:5000/employee/login`

To let other computers on the same network access it, use the server computer's LAN IP, e.g. `http://192.168.1.20:5000`, and allow TCP port 5000 in Windows Firewall.

## Existing database note

If you are upgrading from the earlier login-only app, run `flask --app app init-db` after replacing the old `app.py`. `create_all()` creates the new tables but does not alter existing tables. The earlier `usertble` and `logtble` are compatible with this version, so existing employee accounts and login logs remain.

## Production/security notes

- Passwords are hashed, not stored in plaintext.
- Customer browsing and car selection are public; employee inventory and transaction actions require employee login.
- Browser close logout notification is best-effort; explicit logout is reliable.
- Before public internet deployment, use HTTPS, a strong `SECRET_KEY`, `COOKIE_SECURE=1`, a production WSGI server, database backups, and appropriate employee authorization controls.
- This starter app does not implement payment processing, tax calculation, vehicle title/registration workflows, or multiple employee permission levels.
