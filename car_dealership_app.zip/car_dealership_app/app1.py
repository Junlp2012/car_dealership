import os
import secrets
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash
from sqlalchemy import text

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "CHANGE-ME-use-a-long-random-secret")
db_url = os.environ.get(
    "DATABASE_URL",
    "postgresql+psycopg://postgres:postgres@localhost:5432/car_dealership"
)
if db_url.startswith("postgres://"):
    db_url = db_url.replace("postgres://", "postgresql+psycopg://", 1)
app.config["SQLALCHEMY_DATABASE_URI"] = db_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("COOKIE_SECURE", "0") == "1"

db = SQLAlchemy(app)


class Employee(db.Model):
    __tablename__ = "usertble"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password = db.Column(db.String(255), nullable=False)


class LoginLog(db.Model):
    __tablename__ = "logtble"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("usertble.id"), nullable=False, index=True)
    login_datetime = db.Column(db.DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    logout_datetime = db.Column(db.DateTime(timezone=True))
    session_token = db.Column(db.String(64), unique=True, nullable=False, index=True)


class Car(db.Model):
    __tablename__ = "cartble"
    id = db.Column(db.Integer, primary_key=True)
    make = db.Column(db.String(60), nullable=False)
    model = db.Column(db.String(80), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    category = db.Column(db.String(10), nullable=False)  # New or Used
    price = db.Column(db.Numeric(12, 2), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(15), nullable=False, default="Available")  # Available or Sold
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))


class CarTransaction(db.Model):
    __tablename__ = "cartxntble"
    id = db.Column(db.Integer, primary_key=True)
    car_id = db.Column(db.Integer, db.ForeignKey("cartble.id"), nullable=False, index=True)
    employee_id = db.Column(db.Integer, db.ForeignKey("usertble.id"), nullable=False)
    transaction_type = db.Column(db.String(10), nullable=False)  # Sale or Purchase
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    customer_name = db.Column(db.String(120))
    notes = db.Column(db.Text)
    transaction_datetime = db.Column(db.DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    car = db.relationship("Car")
    employee = db.relationship("Employee")


class CustomerSelection(db.Model):
    __tablename__ = "customer_selectiontble"
    id = db.Column(db.Integer, primary_key=True)
    customer_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160))
    phone = db.Column(db.String(40))
    car_ids = db.Column(db.Text, nullable=False)
    submitted_at = db.Column(db.DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))



class MaintenanceSchedule(db.Model):
    __tablename__ = "maintenance_scheduletble"

    id = db.Column(db.Integer, primary_key=True)

    car_id = db.Column(
        db.Integer,
        db.ForeignKey("cartble.id"),
        nullable=False,
        index=True
    )

    employee_id = db.Column(
        db.Integer,
        db.ForeignKey("usertble.id"),
        nullable=False
    )

    current_mileage = db.Column(db.Integer, nullable=False)
    scheduled_mileage = db.Column(db.Integer, nullable=False)

    service_type = db.Column(db.String(100), nullable=False)
    scheduled_date = db.Column(db.Date, nullable=False)

    estimated_cost = db.Column(db.Numeric(12, 2), default=0)
    notes = db.Column(db.Text)

    status = db.Column(
        db.String(20),
        nullable=False,
        default="Scheduled"
    )

    created_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc)
    )

    car = db.relationship("Car")
    employee = db.relationship("Employee")


# Maintenance recommendations based on vehicle mileage.
def get_maintenance_options(mileage):

    if mileage < 0:
        return []

    options = []

    if mileage < 5000:
        options = [
            "Engine Oil and Filter Change",
            "Tire Pressure Inspection",
            "Brake Inspection",
            "Fluid Level Inspection"
        ]

    elif mileage < 10000:
        options = [
            "Engine Oil and Filter Change",
            "Tire Rotation",
            "Brake Inspection",
            "Battery Inspection",
            "Air Filter Inspection"
        ]

    elif mileage < 15000:
        options = [
            "Engine Oil and Filter Change",
            "Tire Rotation",
            "Engine Air Filter Replacement",
            "Cabin Air Filter Inspection",
            "Brake System Inspection"
        ]

    elif mileage < 30000:
        options = [
            "Engine Oil and Filter Change",
            "Tire Rotation",
            "Brake Fluid Inspection",
            "Transmission Fluid Inspection",
            "Spark Plug Inspection",
            "Coolant System Inspection"
        ]

    elif mileage < 60000:
        options = [
            "Engine Oil and Filter Change",
            "Tire Rotation",
            "Transmission Service",
            "Brake Fluid Replacement",
            "Engine Air Filter Replacement",
            "Spark Plug Inspection",
            "Coolant System Inspection"
        ]

    else:
        options = [
            "Engine Oil and Filter Change",
            "Tire Rotation",
            "Transmission Service",
            "Brake System Inspection",
            "Spark Plug Replacement",
            "Coolant System Service",
            "Timing Belt Inspection",
            "Suspension Inspection",
            "Battery Inspection"
        ]

    return options



def active_log():
    token = session.get("log_token")
    if not token:
        return None
    return LoginLog.query.filter_by(session_token=token, logout_datetime=None).first()


def employee_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("employee_id") or not active_log():
            session.clear()
            flash("Please log in as an employee to access that page.", "error")
            return redirect(url_for("employee_login"))
        return view(*args, **kwargs)
    return wrapped


@app.get("/")
def customer_catalog():
    cars = Car.query.filter_by(status="Available").order_by(Car.category, Car.year.desc(), Car.make).all()
    return render_template("customer.html", cars=cars)


@app.post("/customer/select")
def customer_select():
    selected_ids = request.form.getlist("car_ids")
    name = request.form.get("customer_name", "").strip()
    email = request.form.get("email", "").strip()
    phone = request.form.get("phone", "").strip()
    if not selected_ids:
        flash("Please select at least one available car.", "error")
        return redirect(url_for("customer_catalog"))
    if not name:
        flash("Please enter your name so the dealership can contact you.", "error")
        return redirect(url_for("customer_catalog"))
    valid_ids = []
    for raw_id in selected_ids:
        if raw_id.isdigit():
            car = Car.query.filter_by(id=int(raw_id), status="Available").first()
            if car:
                valid_ids.append(str(car.id))
    if not valid_ids:
        flash("Those cars are no longer available. Please refresh the list.", "error")
        return redirect(url_for("customer_catalog"))
    selection = CustomerSelection(
        customer_name=name, email=email or None, phone=phone or None,
        car_ids=",".join(valid_ids)
    )
    db.session.add(selection)
    db.session.commit()
    flash("Thank you! Your car selection was sent to the dealership.", "success")
    return redirect(url_for("customer_catalog"))


@app.route("/employee/login", methods=["GET", "POST"])
def employee_login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        employee = Employee.query.filter_by(name=username).first()
        if not employee or not check_password_hash(employee.password, password):
            flash("Login failed. Check your username and password and try again.", "error")
            return redirect(url_for("employee_login"))
        token = secrets.token_urlsafe(32)
        db.session.add(LoginLog(user_id=employee.id, session_token=token))
        db.session.commit()
        session.clear()
        session["employee_id"] = employee.id
        session["employee_name"] = employee.name
        session["log_token"] = token
        return redirect(url_for("employee_dashboard"))
    return render_template("employee_login.html")


@app.post("/employee/logout")
def employee_logout():
    log = active_log()
    if log:
        log.logout_datetime = datetime.now(timezone.utc)
        db.session.commit()
    session.clear()
    return redirect(url_for("employee_login"))


@app.post("/employee/close-session")
def employee_close_session():
    log = active_log()
    if log:
        log.logout_datetime = datetime.now(timezone.utc)
        db.session.commit()
    session.clear()
    return ("", 204)


@app.get("/employee")
@employee_required
def employee_dashboard():
    cars = Car.query.order_by(Car.created_at.desc()).all()
    transactions = CarTransaction.query.order_by(CarTransaction.transaction_datetime.desc()).limit(20).all()
    selections = CustomerSelection.query.order_by(CustomerSelection.submitted_at.desc()).limit(20).all()
    available_count = Car.query.filter_by(status="Available").count()
    return render_template(
        "employee.html", cars=cars, transactions=transactions,
        selections=selections, available_count=available_count
    )


@app.post("/employee/car/add")
@employee_required
def add_car():
    try:
        year = int(request.form.get("year", ""))
        price = float(request.form.get("price", ""))
        category = request.form.get("category", "")
        make = request.form.get("make", "").strip()
        model = request.form.get("model", "").strip()
        if not make or not model or category not in ("New", "Used") or year < 1886 or price < 0:
            raise ValueError()
    except (ValueError, TypeError):
        flash("Please enter valid car details, category, year, and price.", "error")
        return redirect(url_for("employee_dashboard"))
    car = Car(
        make=make, model=model, year=year, category=category,
        price=price, description=request.form.get("description", "").strip() or None
    )
    db.session.add(car)
    db.session.commit()
    flash("Car added to inventory.", "success")
    return redirect(url_for("employee_dashboard"))


@app.post("/employee/car/<int:car_id>/sell")
@employee_required
def sell_car(car_id):
    car = Car.query.filter_by(id=car_id, status="Available").first_or_404()
    customer = request.form.get("customer_name", "").strip()
    try:
        amount = float(request.form.get("amount", car.price))
        if amount < 0:
            raise ValueError()
    except ValueError:
        flash("Enter a valid sale price.", "error")
        return redirect(url_for("employee_dashboard"))
    car.status = "Sold"
    db.session.add(CarTransaction(
        car_id=car.id, employee_id=session["employee_id"],
        transaction_type="Sale", amount=amount,
        customer_name=customer or None,
        notes=request.form.get("notes", "").strip() or None
    ))
    db.session.commit()
    flash(f"{car.year} {car.make} {car.model} recorded as sold.", "success")
    return redirect(url_for("employee_dashboard"))


@app.post("/employee/car/purchase")
@employee_required
def purchase_used_car():
    try:
        year = int(request.form.get("year", ""))
        amount = float(request.form.get("amount", ""))
        make = request.form.get("make", "").strip()
        model = request.form.get("model", "").strip()
        if not make or not model or year < 1886 or amount < 0:
            raise ValueError()
    except (ValueError, TypeError):
        flash("Enter valid details for the used car purchase.", "error")
        return redirect(url_for("employee_dashboard"))
    car = Car(
        make=make, model=model, year=year, category="Used",
        price=amount, description=request.form.get("description", "").strip() or "Purchased used vehicle",
        status="Available"
    )
    db.session.add(car)
    db.session.flush()
    db.session.add(CarTransaction(
        car_id=car.id, employee_id=session["employee_id"],
        transaction_type="Purchase", amount=amount,
        customer_name=request.form.get("seller_name", "").strip() or None,
        notes=request.form.get("notes", "").strip() or None
    ))
    db.session.commit()
    flash("Used car purchase recorded and vehicle added to available inventory.", "success")
    return redirect(url_for("employee_dashboard"))


@app.get("/employee/maintenance")
@employee_required
def maintenance_page():

    cars = Car.query.order_by(Car.make, Car.model).all()

    mileage = request.args.get("mileage", type=int)

    if mileage is None or mileage < 0:
        mileage = 0

    options = get_maintenance_options(mileage)

    schedules = MaintenanceSchedule.query.order_by(
        MaintenanceSchedule.scheduled_date.desc()
    ).all()

    return render_template(
        "maintenance.html",
        cars=cars,
        schedules=schedules,
        mileage=mileage,
        options=options
    )


@app.post("/employee/maintenance/schedule")
@employee_required
def schedule_maintenance():

    try:
        car_id = int(request.form.get("car_id", ""))
        current_mileage = int(request.form.get("current_mileage", ""))
        scheduled_mileage = int(request.form.get("scheduled_mileage", ""))
        estimated_cost = float(request.form.get("estimated_cost", "0"))

        scheduled_date = datetime.strptime(
            request.form.get("scheduled_date", ""),
            "%Y-%m-%d"
        ).date()

        service_type = request.form.get("service_type", "").strip()

        car = db.session.get(Car, car_id)

        if not car:
            raise ValueError("Invalid vehicle.")

        if current_mileage < 0:
            raise ValueError("Mileage cannot be negative.")

        if scheduled_mileage < current_mileage:
            raise ValueError(
                "Scheduled mileage cannot be less than current mileage."
            )

        if estimated_cost < 0:
            raise ValueError("Cost cannot be negative.")

        valid_options = get_maintenance_options(current_mileage)

        if service_type not in valid_options:
            raise ValueError("Please select a valid maintenance service.")

    except (ValueError, TypeError):
        flash(
            "Please check the vehicle, mileage, date, service type, and cost.",
            "error"
        )
        return redirect(url_for("maintenance_page"))

    schedule = MaintenanceSchedule(
        car_id=car.id,
        employee_id=session["employee_id"],
        current_mileage=current_mileage,
        scheduled_mileage=scheduled_mileage,
        service_type=service_type,
        scheduled_date=scheduled_date,
        estimated_cost=estimated_cost,
        notes=request.form.get("notes", "").strip() or None
    )

    db.session.add(schedule)
    db.session.commit()

    flash("Vehicle maintenance successfully scheduled!", "success")

    return redirect(url_for("maintenance_page"))


@app.post("/employee/maintenance/<int:schedule_id>/status")
@employee_required
def update_maintenance_status(schedule_id):

    schedule = db.session.get(
        MaintenanceSchedule, schedule_id
    )

    if not schedule:
        flash("Maintenance record not found.", "error")
        return redirect(url_for("maintenance_page"))

    new_status = request.form.get("status", "")

    allowed_statuses = [
        "Scheduled",
        "In Progress",
        "Completed",
        "Cancelled"
    ]

    if new_status not in allowed_statuses:
        flash("Invalid maintenance status.", "error")
        return redirect(url_for("maintenance_page"))

    schedule.status = new_status
    db.session.commit()

    flash("Maintenance status updated successfully.", "success")

    return redirect(url_for("maintenance_page"))


@app.cli.command("init-db")
def init_db():
    db.create_all()
    print("Database tables created.")


@app.cli.command("create-user")
def create_user():
    name = input("Employee username: ").strip()
    from getpass import getpass
    password = getpass("Password: ")
    if not name or not password:
        raise SystemExit("Username and password are required.")
    if Employee.query.filter_by(name=name).first():
        raise SystemExit("That employee username already exists.")
    db.session.add(Employee(name=name, password=generate_password_hash(password)))
    db.session.commit()
    print(f"Created employee account: {name}")


@app.get("/health")
def health():
    db.session.execute(text("SELECT 1"))
    return {"status": "ok"}


# if __name__ == "__main__":
#     app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=int(os.environ.get("PORT", "5000")),
        debug=True,
        use_reloader=True
    )